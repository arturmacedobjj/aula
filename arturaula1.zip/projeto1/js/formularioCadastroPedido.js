function enviarPedido(){
    var nome = document.getElementById("nome");
    var telefone = document.getElementById("telefone");
    var email = document.getElementById("email");
    var pedido = document.getElementById("pedido");

    if(nome.value != "" && telefone.value != "" && email.value != "" && pedido.value != ""){
        alert('Pedido Enviado com sucesso')
        window.location.reload(true)
    }
    else{
        alert('É necessário preencher todos os campos!')
    }
    
}
